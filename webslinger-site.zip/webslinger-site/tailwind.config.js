/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        void: {
          DEFAULT: "#07070a",
          soft: "#0d0d12",
          faint: "#141420"
        },
        crimson: {
          DEFAULT: "#e2231a",
          bright: "#ff3b30",
          dim: "#7a1610"
        },
        webblue: {
          DEFAULT: "#1147c9",
          bright: "#3b6bff",
          dim: "#0b2a73"
        },
        chalk: {
          DEFAULT: "#f2f0ec",
          dim: "#c9c7c2"
        }
      },
      fontFamily: {
        display: ["'Anton'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"]
      },
      letterSpacing: {
        widest2: "0.35em"
      }
    }
  },
  plugins: []
};
