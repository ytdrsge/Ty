import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function ScrollProgress() {
  const barRef = useRef<HTMLDivElement>(null);
  const numRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const trigger = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => {
        const pct = self.progress;
        gsap.set(barRef.current, { scaleY: pct });
        if (numRef.current) {
          numRef.current.textContent = String(
            Math.round(pct * 100)
          ).padStart(2, "0");
        }
      }
    });

    return () => trigger.kill();
  }, []);

  return (
    <div className="fixed right-4 md:right-6 top-1/2 -translate-y-1/2 z-[70] hidden sm:flex flex-col items-center gap-3 pointer-events-none">
      <span className="font-mono text-[10px] tracking-widest2 text-crimson-bright/80">
        <span ref={numRef}>00</span>
      </span>
      <div className="relative w-px h-24 bg-chalk/15 overflow-hidden">
        <div
          ref={barRef}
          className="absolute top-0 left-0 w-full h-full bg-crimson origin-top"
          style={{ transform: "scaleY(0)" }}
        />
      </div>
    </div>
  );
}
