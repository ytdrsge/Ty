import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function Footer() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const oversizedRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(oversizedRef.current, {
        yPercent: -25,
        scale: 0.85,
        ease: "none",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top bottom",
          end: "top top",
          scrub: true
        }
      });

      gsap.from(".footer-fade", {
        opacity: 0,
        y: 24,
        stagger: 0.08,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: { trigger: sectionRef.current, start: "top 70%" }
      });
    }, sectionRef);

    const isFinePointer = window.matchMedia(
      "(hover: hover) and (pointer: fine)"
    ).matches;

    let cleanup = () => {};

    if (isFinePointer && ctaRef.current) {
      const btn = ctaRef.current;
      const moveX = gsap.quickTo(btn, "x", { duration: 0.4, ease: "power3" });
      const moveY = gsap.quickTo(btn, "y", { duration: 0.4, ease: "power3" });

      const onMove = (e: PointerEvent) => {
        const rect = btn.getBoundingClientRect();
        const relX = e.clientX - (rect.left + rect.width / 2);
        const relY = e.clientY - (rect.top + rect.height / 2);
        moveX(relX * 0.3);
        moveY(relY * 0.3);
      };
      const onLeave = () => {
        moveX(0);
        moveY(0);
      };

      btn.addEventListener("pointermove", onMove);
      btn.addEventListener("pointerleave", onLeave);
      cleanup = () => {
        btn.removeEventListener("pointermove", onMove);
        btn.removeEventListener("pointerleave", onLeave);
      };
    }

    return () => {
      ctx.revert();
      cleanup();
    };
  }, []);

  return (
    <>
      <div
        ref={oversizedRef}
        className="relative bg-chalk h-[24vh] md:h-[30vh] flex items-center justify-center overflow-hidden pointer-events-none"
      >
        <span className="font-display text-[15vw] leading-none text-void/[0.07] select-none whitespace-nowrap">
          Stay Vigilant
        </span>
      </div>

      <footer
        ref={sectionRef}
        id="footer"
        className="relative bg-void text-chalk pt-20 md:pt-28 pb-10 px-6 md:px-10"
      >
        <div className="max-w-[1400px] mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-10 md:gap-6 border-b border-chalk/10 pb-16 md:pb-20">
            <div className="max-w-xl">
              <span className="footer-fade block font-mono text-[11px] tracking-widest2 uppercase text-crimson-bright/80 mb-5">
                Neighborhood Watch — Open Enrollment
              </span>
              <h2 className="footer-fade font-display text-4xl md:text-6xl leading-[1.0]">
                Report a
                <br />
                sighting.
              </h2>
            </div>

            <a
              ref={ctaRef}
              href="mailto:tips@webslinger-fanpage.example"
              data-cursor="Send"
              className="footer-fade shrink-0 inline-flex items-center justify-center w-40 h-40 md:w-48 md:h-48 rounded-full border border-crimson/60 text-center font-body text-xs md:text-sm tracking-[0.14em] uppercase text-crimson-bright hover:bg-crimson hover:text-chalk transition-colors duration-500"
            >
              Send a
              <br />
              Tip
            </a>
          </div>

          <div className="footer-fade flex flex-col md:flex-row md:items-center justify-between gap-6 pt-10 text-xs text-chalk/45 font-body">
            <span>
              An unofficial fan tribute · not affiliated with or endorsed by
              any studio or publisher.
            </span>
            <div className="flex items-center gap-6">
              <span className="underline-elegant cursor-default">
                tips@webslinger-fanpage.example
              </span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
