import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface Step {
  index: string;
  title: string;
  body: string;
  tone: string;
}

const STEPS: Step[] = [
  {
    index: "I",
    title: "An ordinary field trip.",
    body: "A quiet, bookish kid gets bitten by something in a lab that was never meant to bite anyone.",
    tone: "#0b2a73"
  },
  {
    index: "II",
    title: "The strength arrives first.",
    body: "Overnight, ordinary limits stop applying. Speed, grip, reflexes — all of it, suddenly too much to hide.",
    tone: "#0d0d12"
  },
  {
    index: "III",
    title: "A hard lesson, learned too late.",
    body: "A choice not to act costs someone he loved everything. The lesson sticks for good.",
    tone: "#141420"
  },
  {
    index: "IV",
    title: "A mask, and a promise.",
    body: "From that night on, the city gets a watcher who never clocks out — however tired, however alone.",
    tone: "#07070a"
  }
];

export default function OriginStory() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelsRef = useRef<(HTMLDivElement | null)[]>([]);
  const dialRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const panels = panelsRef.current.filter(Boolean) as HTMLDivElement[];

      gsap.set(panels, { opacity: 0, y: 40 });
      gsap.set(panels[0], { opacity: 1, y: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: `+=${STEPS.length * 100}%`,
          scrub: 0.8,
          pin: true,
          anticipatePin: 1
        }
      });

      tl.to(
        dialRef.current,
        { rotate: 360, scale: 1.3, ease: "none", duration: STEPS.length },
        0
      );

      panels.forEach((panel, i) => {
        if (i === 0) return;
        const prev = panels[i - 1];
        const segmentStart = i - 1 + 0.55;

        tl.to(
          prev,
          { opacity: 0, y: -40, duration: 0.45, ease: "power2.inOut" },
          segmentStart
        ).fromTo(
          panel,
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.45, ease: "power2.inOut" },
          segmentStart
        );

        tl.to(
          bgRef.current,
          {
            backgroundColor: STEPS[i].tone,
            duration: 0.45,
            ease: "power2.inOut"
          },
          segmentStart
        );
      });

      tl.eventCallback("onUpdate", () => {
        const progress = tl.progress() * STEPS.length;
        markersRef.current.forEach((m, i) => {
          if (!m) return;
          const active = progress >= i - 0.02;
          m.style.opacity = active ? "1" : "0.25";
          m.style.transform = active ? "scaleY(1)" : "scaleY(0.4)";
        });
      });

      return () => {
        tl.scrollTrigger?.kill();
        tl.kill();
      };
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="origin"
      className="relative h-[100svh] w-full overflow-hidden"
    >
      <div
        ref={bgRef}
        className="absolute inset-0 transition-none"
        style={{ backgroundColor: STEPS[0].tone }}
      />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(226,35,26,0.12),transparent_60%)]" />

      <div
        ref={dialRef}
        className="absolute -right-[10%] top-1/2 -translate-y-1/2 w-[70vw] max-w-[720px] aspect-square pointer-events-none opacity-30 md:opacity-40"
      >
        <div className="absolute inset-0 rounded-full border border-crimson/40" />
        <div className="absolute inset-[8%] rounded-full border border-chalk/15" />
        <div className="absolute inset-[16%] rounded-full border border-crimson/25" />
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 w-px h-[10%] bg-chalk/25 origin-bottom"
            style={{ transform: `rotate(${i * 30}deg) translateY(-100%)` }}
          />
        ))}
      </div>

      <div className="relative z-10 h-full max-w-[1400px] mx-auto px-6 md:px-10 flex flex-col justify-center">
        <div className="flex items-center gap-2 mb-8 md:mb-12">
          {STEPS.map((step, i) => (
            <span
              key={step.index}
              ref={(el) => (markersRef.current[i] = el)}
              className="h-1.5 w-10 md:w-16 bg-crimson-bright rounded-full origin-left transition-opacity duration-300"
              style={{ opacity: i === 0 ? 1 : 0.25 }}
            />
          ))}
        </div>

        <div className="relative h-[42vh] md:h-[38vh] max-w-2xl">
          {STEPS.map((step, i) => (
            <div
              key={step.index}
              ref={(el) => (panelsRef.current[i] = el)}
              className="absolute inset-0 flex flex-col justify-center"
            >
              <span className="font-display text-crimson-bright/80 text-2xl mb-4">
                {step.index}
              </span>
              <h3 className="font-display text-4xl md:text-6xl text-chalk leading-[1.0] max-w-lg">
                {step.title}
              </h3>
              <p className="font-body text-chalk/65 text-sm md:text-base mt-6 max-w-md leading-relaxed">
                {step.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
