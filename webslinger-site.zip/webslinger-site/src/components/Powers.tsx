import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { powers } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function Powers() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        gsap.fromTo(
          card,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: "power3.out",
            delay: i * 0.08,
            scrollTrigger: { trigger: card, start: "top 85%" }
          }
        );
      });
    }, sectionRef);

    const isFinePointer = window.matchMedia(
      "(hover: hover) and (pointer: fine)"
    ).matches;

    const cleanups: Array<() => void> = [];

    if (isFinePointer) {
      cardsRef.current.forEach((card) => {
        if (!card) return;

        const rotX = gsap.quickTo(card, "rotationX", {
          duration: 0.6,
          ease: "power3"
        });
        const rotY = gsap.quickTo(card, "rotationY", {
          duration: 0.6,
          ease: "power3"
        });
        const liftY = gsap.quickTo(card, "y", {
          duration: 0.6,
          ease: "power3"
        });

        const onMove = (e: PointerEvent) => {
          const rect = card.getBoundingClientRect();
          const px = (e.clientX - rect.left) / rect.width - 0.5;
          const py = (e.clientY - rect.top) / rect.height - 0.5;
          rotY(px * 10);
          rotX(-py * 10);
          liftY(-6);
        };
        const onLeave = () => {
          rotX(0);
          rotY(0);
          liftY(0);
        };

        card.style.transformPerspective = "800px";
        card.addEventListener("pointermove", onMove);
        card.addEventListener("pointerleave", onLeave);

        cleanups.push(() => {
          card.removeEventListener("pointermove", onMove);
          card.removeEventListener("pointerleave", onLeave);
        });
      });
    }

    return () => {
      ctx.revert();
      cleanups.forEach((fn) => fn());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="powers"
      className="relative bg-webblue-dim py-28 md:py-40 px-6 md:px-10 overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(226,35,26,0.1),transparent_60%)] pointer-events-none" />

      <div className="relative max-w-[1400px] mx-auto">
        <div className="max-w-xl mb-16 md:mb-24">
          <span className="font-mono text-[11px] tracking-widest2 uppercase text-crimson-bright/80">
            Field Notes
          </span>
          <h2 className="font-display text-4xl md:text-6xl text-chalk mt-4 leading-[1.0]">
            Not born.
            <br />
            <span className="text-crimson-bright">Built by accident.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-5 md:gap-6">
          {powers.map((f, i) => (
            <div
              key={f.title}
              ref={(el) => (cardsRef.current[i] = el)}
              className="glass rounded-[2px] p-8 md:p-9 will-change-transform"
              style={{ transformStyle: "preserve-3d" }}
            >
              <span className="font-mono text-[10px] tracking-widest2 uppercase text-crimson-bright/80">
                {f.eyebrow}
              </span>
              <h3 className="font-display text-2xl md:text-[26px] text-chalk mt-4 leading-snug normal-case">
                {f.title}
              </h3>
              <p className="font-body text-sm text-chalk/60 mt-4 leading-relaxed">
                {f.body}
              </p>
              <div className="hairline mt-8" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
