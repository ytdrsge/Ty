import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { rogues } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function RoguesShowcase() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const progressLabelRef = useRef<HTMLSpanElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const track = trackRef.current!;
      const section = sectionRef.current!;

      const getScrollDistance = () => track.scrollWidth - window.innerWidth;

      const st = ScrollTrigger.create({
        trigger: section,
        start: "top top",
        end: () => `+=${getScrollDistance() + window.innerHeight * 0.4}`,
        pin: true,
        scrub: 0.7,
        anticipatePin: 1,
        onUpdate: (self) => {
          const distance = getScrollDistance();
          const x = -distance * self.progress;
          gsap.set(track, { x });

          if (progressLabelRef.current) {
            const idx = Math.min(
              rogues.length - 1,
              Math.round(self.progress * (rogues.length - 1))
            );
            progressLabelRef.current.textContent = `${String(
              idx + 1
            ).padStart(2, "0")} / ${String(rogues.length).padStart(2, "0")}`;
          }

          const viewportCenter = window.innerWidth / 2;
          cardsRef.current.forEach((card) => {
            if (!card) return;
            const rect = card.getBoundingClientRect();
            const cardCenter = rect.left + rect.width / 2;
            const dist = Math.abs(cardCenter - viewportCenter);
            const norm = Math.min(1, dist / (window.innerWidth * 0.65));
            gsap.set(card, {
              scale: 1 - norm * 0.14,
              filter: `blur(${norm * 3}px)`,
              opacity: 1 - norm * 0.35
            });
          });
        }
      });

      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: { trigger: section, start: "top 70%" }
        }
      );

      return () => st.kill();
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="gallery"
      className="relative h-[100svh] w-full bg-void overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(17,71,201,0.25),transparent_55%)] pointer-events-none" />

      <div
        ref={headingRef}
        className="absolute top-10 md:top-14 left-6 md:left-10 z-10 flex items-end justify-between right-6 md:right-10"
      >
        <div>
          <span className="font-mono text-[11px] tracking-widest2 uppercase text-crimson-bright/80">
            Case Files
          </span>
          <h2 className="font-display text-3xl md:text-5xl text-chalk mt-3 max-w-lg">
            The Rogues
            <br />
            Gallery.
          </h2>
        </div>
        <span
          ref={progressLabelRef}
          className="font-mono text-xs tracking-widest text-chalk/50 hidden sm:block"
        >
          01 / 05
        </span>
      </div>

      <div
        ref={trackRef}
        className="flex items-center h-full pl-[8vw] md:pl-[14vw] pr-[10vw] gap-6 md:gap-10 will-change-transform"
      >
        {rogues.map((item, i) => (
          <div
            key={item.code}
            ref={(el) => (cardsRef.current[i] = el)}
            data-cursor="File"
            className="relative shrink-0 w-[78vw] sm:w-[54vw] md:w-[32vw] h-[62vh] md:h-[68vh] rounded-[2px] overflow-hidden glass group cursor-pointer"
          >
            <div
              className="absolute inset-0 transition-transform duration-700 group-hover:scale-105"
              style={{
                background: `linear-gradient(155deg, ${item.colorFrom}, ${item.colorTo})`
              }}
            />
            <div className="absolute inset-0 halftone opacity-30 mix-blend-overlay" />

            <div className="relative h-full flex flex-col justify-between p-6 md:p-8">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] tracking-widest2 text-crimson-bright/90">
                  {item.code}
                </span>
                <span className="font-mono text-[10px] tracking-widest uppercase text-chalk/50">
                  Threat Level
                </span>
              </div>

              <div className="flex-1 flex items-center justify-center">
                <div className="relative w-40 h-40 md:w-52 md:h-52 rounded-full border border-crimson/40 flex items-center justify-center transition-transform duration-700 group-hover:rotate-45">
                  <div className="absolute inset-3 rounded-full border border-chalk/10" />
                  <div className="absolute inset-8 rounded-full border border-crimson/20" />
                  <div className="w-1.5 h-1.5 rounded-full bg-crimson-bright" />
                  <div className="absolute top-4 left-1/2 -translate-x-1/2 w-px h-8 bg-chalk/40" />
                </div>
              </div>

              <div>
                <h3 className="font-display text-2xl md:text-3xl text-chalk">
                  {item.name}
                </h3>
                <p className="font-body text-xs md:text-sm text-chalk/60 mt-2">
                  {item.threat}
                </p>
                <p className="font-body text-xs md:text-sm text-crimson-bright/80 mt-1">
                  {item.domain}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
