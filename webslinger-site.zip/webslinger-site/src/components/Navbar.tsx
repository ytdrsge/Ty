import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { getLenis } from "../lib/lenis";

gsap.registerPlugin(ScrollTrigger);

const LINKS = [
  { label: "Gallery", target: "#gallery" },
  { label: "Origin", target: "#origin" },
  { label: "Powers", target: "#powers" },
  { label: "Join Up", target: "#footer" }
];

export default function Navbar() {
  const navRef = useRef<HTMLDivElement>(null);
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const trigger = ScrollTrigger.create({
      start: 80,
      end: 99999,
      onUpdate: (self) => setScrolled(self.scroll() > 80),
      onToggle: (self) => setScrolled(self.isActive)
    });
    return () => trigger.kill();
  }, []);

  const goTo = (selector: string) => {
    setOpen(false);
    const el = document.querySelector(selector);
    if (!el) return;
    const lenis = getLenis();
    if (lenis) {
      lenis.scrollTo(el as HTMLElement, { offset: -40, duration: 1.4 });
    } else {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div
      ref={navRef}
      className={`fixed top-0 left-0 right-0 z-[80] transition-all duration-700 ${
        scrolled ? "py-3" : "py-6 md:py-8"
      }`}
    >
      <div
        className={`mx-auto max-w-[1400px] px-5 md:px-10 flex items-center justify-between rounded-full transition-all duration-700 ${
          scrolled ? "glass mx-4 md:mx-10 py-2.5 px-6" : "bg-transparent"
        }`}
      >
        <a
          href="#top"
          data-cursor=""
          onClick={(e) => {
            e.preventDefault();
            goTo("#top");
          }}
          className="font-display text-lg md:text-xl tracking-[0.08em] text-chalk"
        >
          WEB-SLINGER
        </a>

        <nav className="hidden md:flex items-center gap-10">
          {LINKS.map((link) => (
            <button
              key={link.label}
              data-cursor=""
              onClick={() => goTo(link.target)}
              className="underline-elegant font-body text-[13px] tracking-[0.12em] uppercase text-chalk/80 hover:text-crimson-bright transition-colors"
            >
              {link.label}
            </button>
          ))}
        </nav>

        <button
          data-cursor=""
          onClick={() => goTo("#footer")}
          className="hidden md:inline-flex items-center gap-2 border border-crimson/60 text-crimson-bright text-[12px] tracking-[0.14em] uppercase px-5 py-2.5 rounded-full hover:bg-crimson hover:text-chalk transition-colors duration-500"
        >
          Sound the Alert
        </button>

        <button
          aria-label="Toggle menu"
          className="md:hidden flex flex-col gap-1.5 w-7"
          onClick={() => setOpen((v) => !v)}
        >
          <span
            className={`h-px bg-chalk transition-transform duration-300 ${
              open ? "translate-y-[3px] rotate-45" : ""
            }`}
          />
          <span
            className={`h-px bg-chalk transition-transform duration-300 ${
              open ? "-translate-y-[3px] -rotate-45" : ""
            }`}
          />
        </button>
      </div>

      {open && (
        <div className="md:hidden mx-4 mt-3 glass-strong rounded-3xl px-6 py-6 flex flex-col gap-5">
          {LINKS.map((link) => (
            <button
              key={link.label}
              onClick={() => goTo(link.target)}
              className="text-left font-display text-2xl text-chalk"
            >
              {link.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
