import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { stats } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function Counters() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const numRefs = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      stats.forEach((stat, i) => {
        const el = numRefs.current[i];
        if (!el) return;
        const counter = { val: 0 };
        gsap.to(counter, {
          val: stat.value,
          duration: 1.8,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 75%" },
          onUpdate: () => {
            el.textContent = Math.round(counter.val).toLocaleString();
          }
        });
      });

      gsap.utils.toArray<HTMLElement>(".stat-block").forEach((block, i) => {
        gsap.from(block, {
          opacity: 0,
          y: 30,
          duration: 0.9,
          delay: i * 0.06,
          ease: "power3.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 75%" }
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative bg-chalk text-void py-24 md:py-32 px-6 md:px-10"
    >
      <div className="max-w-[1400px] mx-auto">
        <div className="flex items-center gap-3 mb-14 md:mb-20">
          <span className="w-8 h-px bg-crimson" />
          <span className="font-mono text-[11px] tracking-widest2 uppercase text-crimson-dim">
            The Ledger
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-14">
          {stats.map((stat, i) => (
            <div key={stat.label} className="stat-block">
              <div className="font-display text-5xl md:text-7xl text-void flex items-baseline">
                <span ref={(el) => (numRefs.current[i] = el)}>0</span>
                <span className="text-crimson ml-1 text-3xl md:text-4xl">
                  {stat.suffix}
                </span>
              </div>
              <p className="font-body text-xs md:text-sm text-void/55 mt-3 max-w-[18ch] leading-relaxed">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
