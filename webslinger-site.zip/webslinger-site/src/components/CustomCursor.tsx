import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

/**
 * Desktop-only crosshair cursor themed as a "web-shooter" targeting
 * reticle. Clicking anywhere fires a brief burst of thin lines from
 * the cursor position, like a web-shot, then fades. Hoverable elements
 * marked data-cursor show a label beneath the reticle.
 */
export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const burstLayerRef = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    const isFinePointer = window.matchMedia(
      "(hover: hover) and (pointer: fine)"
    ).matches;
    setEnabled(isFinePointer);
    if (!isFinePointer) return;

    document.body.classList.add("cursor-enabled");

    const dot = dotRef.current!;
    const ring = ringRef.current!;
    const label = labelRef.current!;
    const burstLayer = burstLayerRef.current!;

    const dotX = gsap.quickTo(dot, "x", { duration: 0.1, ease: "power3" });
    const dotY = gsap.quickTo(dot, "y", { duration: 0.1, ease: "power3" });
    const ringX = gsap.quickTo(ring, "x", { duration: 0.35, ease: "power3" });
    const ringY = gsap.quickTo(ring, "y", { duration: 0.35, ease: "power3" });

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;

    const onMove = (e: PointerEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      dotX(mouseX);
      dotY(mouseY);
      ringX(mouseX);
      ringY(mouseY);
    };

    const onOver = (e: PointerEvent) => {
      const target = e.target as HTMLElement;
      const hoverEl = target?.closest<HTMLElement>("[data-cursor]");
      if (hoverEl) {
        const text = hoverEl.getAttribute("data-cursor") || "";
        label.textContent = text;
        gsap.to(ring, {
          width: 56,
          height: 56,
          marginLeft: -28,
          marginTop: -28,
          duration: 0.35,
          ease: "power3.out"
        });
        gsap.to(label, { opacity: 1, duration: 0.3, delay: 0.05 });
        gsap.to(dot, { scale: 0, duration: 0.25 });
      }
    };

    const onOut = (e: PointerEvent) => {
      const target = e.target as HTMLElement;
      const hoverEl = target?.closest<HTMLElement>("[data-cursor]");
      const related = e.relatedTarget as HTMLElement | null;
      const stillInside = related?.closest?.("[data-cursor]");
      if (hoverEl && !stillInside) {
        gsap.to(ring, {
          width: 40,
          height: 40,
          marginLeft: -20,
          marginTop: -20,
          duration: 0.35,
          ease: "power3.out"
        });
        gsap.to(label, { opacity: 0, duration: 0.2 });
        gsap.to(dot, { scale: 1, duration: 0.25 });
      }
    };

    const onDown = (e: PointerEvent) => {
      gsap.to([dot, ring], { scale: 0.8, duration: 0.12 });

      // Fire a small burst of thin web-lines from the click point.
      const lineCount = 6;
      for (let i = 0; i < lineCount; i++) {
        const line = document.createElement("div");
        const angle = (360 / lineCount) * i + Math.random() * 20;
        line.style.position = "fixed";
        line.style.left = `${e.clientX}px`;
        line.style.top = `${e.clientY}px`;
        line.style.width = "1px";
        line.style.height = "1px";
        line.style.background = "rgba(226,35,26,0.75)";
        line.style.transformOrigin = "top left";
        line.style.pointerEvents = "none";
        line.style.zIndex = "9997";
        burstLayer.appendChild(line);

        gsap.to(line, {
          height: 34 + Math.random() * 20,
          width: 1,
          rotate: angle,
          opacity: 0,
          duration: 0.55,
          ease: "power2.out",
          onComplete: () => line.remove()
        });
      }
    };
    const onUp = () => gsap.to([dot, ring], { scale: 1, duration: 0.25 });

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerover", onOver);
    window.addEventListener("pointerout", onOut);
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp);

    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      window.removeEventListener("pointerout", onOut);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      document.body.classList.remove("cursor-enabled");
    };
  }, []);

  if (!enabled) return null;

  return (
    <>
      <div ref={burstLayerRef} />
      <div ref={dotRef} className="cursor-dot" />
      <div ref={ringRef} className="cursor-ring">
        <span ref={labelRef} className="cursor-label" />
      </div>
    </>
  );
}
