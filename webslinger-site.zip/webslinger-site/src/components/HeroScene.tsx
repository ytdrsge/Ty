import { Suspense, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface SceneProps {
  scrollProgress: React.MutableRefObject<number>;
}

/** A field of simple low-poly boxes standing in for a city skyline. */
function Skyline() {
  const buildings = useMemo(() => {
    const list: { x: number; z: number; h: number; w: number }[] = [];
    for (let i = 0; i < 40; i++) {
      list.push({
        x: (Math.random() - 0.5) * 22,
        z: -Math.random() * 18 - 2,
        h: 1 + Math.random() * 5,
        w: 0.6 + Math.random() * 1.1
      });
    }
    return list;
  }, []);

  return (
    <group position={[0, -3, 0]}>
      {buildings.map((b, i) => (
        <mesh key={i} position={[b.x, b.h / 2, b.z]}>
          <boxGeometry args={[b.w, b.h, b.w]} />
          <meshStandardMaterial
            color="#0d0d12"
            emissive="#1147c9"
            emissiveIntensity={0.06}
            roughness={0.9}
          />
        </mesh>
      ))}
    </group>
  );
}

/** A glowing particle tracing an arcing swing-line across the scene. */
function SwingTrail({ scrollProgress }: SceneProps) {
  const pointRef = useRef<THREE.Mesh>(null);
  const lineRef = useRef<THREE.Line>(null);

  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(-8, 4, -2),
      new THREE.Vector3(-3, -1.5, 0),
      new THREE.Vector3(0, 3.5, 1),
      new THREE.Vector3(3, -1.5, 0),
      new THREE.Vector3(8, 4, -2)
    ]);
  }, []);

  const lineGeometry = useMemo(() => {
    const points = curve.getPoints(80);
    return new THREE.BufferGeometry().setFromPoints(points);
  }, [curve]);

  useFrame((state) => {
    const t =
      (Math.sin(state.clock.elapsedTime * 0.35) + 1) / 2 +
      scrollProgress.current * 0.15;
    const clamped = Math.max(0, Math.min(1, t));
    const pos = curve.getPoint(clamped);
    if (pointRef.current) {
      pointRef.current.position.copy(pos);
    }
  });

  return (
    <group>
      {/* eslint-disable-next-line react/no-unknown-property */}
      <line ref={lineRef as any} geometry={lineGeometry}>
        <lineBasicMaterial
          color="#e2231a"
          transparent
          opacity={0.35}
          linewidth={1}
        />
      </line>
      <mesh ref={pointRef}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshStandardMaterial
          color="#ff3b30"
          emissive="#ff3b30"
          emissiveIntensity={2.2}
        />
      </mesh>
    </group>
  );
}

function RigCamera({ scrollProgress }: SceneProps) {
  useFrame((state) => {
    const p = scrollProgress.current;
    state.camera.position.x = Math.sin(state.clock.elapsedTime * 0.08) * 0.6;
    state.camera.position.y = 1.2 - p * 1.4;
    state.camera.position.z = 9 + p * 2;
    state.camera.lookAt(0, 0, -2);
  });
  return null;
}

export default function HeroScene({ scrollProgress }: SceneProps) {
  return (
    <Canvas
      dpr={[1, 1.75]}
      camera={{ position: [0, 1, 9], fov: 50 }}
      gl={{ antialias: true, alpha: true }}
      className="!absolute inset-0"
    >
      <fog attach="fog" args={["#07070a", 6, 24]} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[4, 6, 4]} intensity={1.1} color="#f2f0ec" />
      <pointLight position={[-4, -1, 2]} intensity={1.4} color="#e2231a" />

      <Suspense fallback={null}>
        <Skyline />
        <SwingTrail scrollProgress={scrollProgress} />
        <RigCamera scrollProgress={scrollProgress} />
      </Suspense>
    </Canvas>
  );
}
