import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import HeroScene from "./HeroScene";

gsap.registerPlugin(ScrollTrigger, SplitText);

export default function Hero() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const sceneWrapRef = useRef<HTMLDivElement>(null);
  const bgTextRef = useRef<HTMLDivElement>(null);
  const scrollCueRef = useRef<HTMLDivElement>(null);
  const scrollProgress = useRef(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const split = new SplitText(headlineRef.current, {
        type: "lines,words",
        linesClass: "split-line"
      });

      const tl = gsap.timeline({ delay: 0.3 });

      tl.from(labelRef.current, {
        opacity: 0,
        y: 14,
        duration: 0.8,
        ease: "power3.out"
      })
        .from(
          split.words,
          {
            yPercent: 130,
            rotate: 3,
            opacity: 0,
            duration: 1.1,
            stagger: 0.045,
            ease: "power4.out"
          },
          "-=0.4"
        )
        .from(
          subRef.current,
          { opacity: 0, y: 16, duration: 0.9, ease: "power3.out" },
          "-=0.6"
        )
        .from(
          ctaRef.current,
          { opacity: 0, y: 16, duration: 0.9, ease: "power3.out" },
          "-=0.7"
        )
        .from(
          sceneWrapRef.current,
          { opacity: 0, scale: 0.85, duration: 1.4, ease: "power3.out" },
          "-=1.2"
        )
        .to(scrollCueRef.current, { opacity: 1, duration: 0.6 }, "-=0.3");

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "bottom top",
          scrub: 0.6,
          onUpdate: (self) => {
            scrollProgress.current = self.progress;
          }
        }
      });

      scrollTl
        .to(labelRef.current, { yPercent: -120, opacity: 0 }, 0)
        .to(headlineRef.current, { yPercent: -35, opacity: 0.15 }, 0)
        .to(split.words, { xPercent: (i) => (i % 2 === 0 ? -14 : 14) }, 0)
        .to(subRef.current, { yPercent: -60, opacity: 0 }, 0)
        .to(ctaRef.current, { yPercent: -30, opacity: 0 }, 0)
        .to(sceneWrapRef.current, { yPercent: -8, scale: 1.1 }, 0)
        .to(bgTextRef.current, { scale: 1.5, opacity: 0 }, 0)
        .to(scrollCueRef.current, { opacity: 0 }, 0);

      return () => split.revert();
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="top"
      className="relative h-[100svh] w-full overflow-hidden bg-void flex items-center justify-center web-pattern"
    >
      <div
        ref={bgTextRef}
        className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
      >
        <span className="font-display text-[22vw] leading-none text-chalk/[0.035] tracking-tighter">
          NIGHT WATCH
        </span>
      </div>

      <div ref={sceneWrapRef} className="absolute inset-0 opacity-95">
        <HeroScene scrollProgress={scrollProgress} />
      </div>

      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_15%,rgba(7,7,10,0.55)_70%,rgba(7,7,10,0.95)_100%)] pointer-events-none" />

      <div className="relative z-10 max-w-[1400px] w-full px-6 md:px-10 mx-auto">
        <div ref={labelRef} className="flex items-center gap-3 mb-6 md:mb-8">
          <span className="w-8 h-px bg-crimson-bright/80" />
          <span className="font-mono text-[11px] md:text-xs tracking-widest2 uppercase text-crimson-bright/90">
            An Unofficial Fan Tribute
          </span>
        </div>

        <h1
          ref={headlineRef}
          className="font-display text-[15vw] sm:text-[11vw] md:text-[7vw] leading-[0.9] text-chalk max-w-4xl"
        >
          Your friendly
          <br />
          <span className="text-crimson-bright">neighborhood</span>
          <br />
          web-slinger.
        </h1>

        <p
          ref={subRef}
          className="mt-6 md:mt-8 max-w-md font-body text-sm md:text-base text-chalk/70 leading-relaxed"
        >
          Great power, greater responsibility, and a whole lot of swinging
          between rooftops. Scroll to trace the city he watches over.
        </p>

        <div ref={ctaRef} className="mt-9 md:mt-12 flex items-center gap-6">
          <a
            href="#gallery"
            data-cursor="Swing"
            onClick={(e) => {
              e.preventDefault();
              document
                .querySelector("#gallery")
                ?.scrollIntoView({ behavior: "smooth" });
            }}
            className="group inline-flex items-center gap-3 bg-crimson text-chalk text-[12px] tracking-[0.14em] uppercase font-medium px-7 py-4 rounded-full transition-transform duration-500 hover:scale-[1.03]"
          >
            Meet the Rogues Gallery
            <span className="inline-block transition-transform duration-500 group-hover:translate-x-1">
              →
            </span>
          </a>
          <span className="font-mono text-[11px] tracking-widest text-chalk/40 hidden sm:inline">
            NIGHT SHIFT / ACTIVE
          </span>
        </div>
      </div>

      <div
        ref={scrollCueRef}
        className="absolute bottom-8 md:bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 opacity-0 z-10"
      >
        <span className="font-mono text-[10px] tracking-widest2 uppercase text-chalk/50">
          Scroll
        </span>
        <div className="w-px h-10 bg-gradient-to-b from-crimson-bright/70 to-transparent" />
      </div>
    </section>
  );
}
