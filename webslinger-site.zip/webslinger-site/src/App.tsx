import { useEffect, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { initSmoothScroll } from "./lib/lenis";

import Grain from "./components/Grain";
import CustomCursor from "./components/CustomCursor";
import ScrollProgress from "./components/ScrollProgress";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import RoguesShowcase from "./components/RoguesShowcase";
import OriginStory from "./components/OriginStory";
import Powers from "./components/Powers";
import Counters from "./components/Counters";
import Footer from "./components/Footer";

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    initSmoothScroll();

    const t = setTimeout(() => {
      ScrollTrigger.refresh();
      setReady(true);
    }, 120);

    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener("load", onLoad);

    return () => {
      clearTimeout(t);
      window.removeEventListener("load", onLoad);
    };
  }, []);

  return (
    <div
      className="relative bg-void"
      style={{ opacity: ready ? 1 : 0, transition: "opacity 0.4s ease" }}
    >
      <Grain />
      <CustomCursor />
      <ScrollProgress />
      <Navbar />

      <main>
        <Hero />
        <RoguesShowcase />
        <OriginStory />
        <Powers />
        <Counters />
        <Footer />
      </main>
    </div>
  );
}
